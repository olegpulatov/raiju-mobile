package xyz.block.buzz.mobile

import android.content.Intent

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.media.MediaExtractor
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.Build
import androidx.annotation.RequiresApi
import com.google.android.play.agesignals.AgeSignalsException
import com.google.android.play.agesignals.model.AgeSignalsErrorCode
import com.google.android.play.agesignals.AgeSignalsAccessRequest
import com.google.android.play.agesignals.AgeSignalsManager
import com.google.android.play.agesignals.AgeSignalsManagerFactory
import com.google.android.play.agesignals.AgeSignalsRequest
import com.google.android.play.agesignals.model.AgeSignalsStatus
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.util.UUID

internal fun ageSignalPayload(ageUpper: Int?): Map<String, Any?> {
    return mapOf(
        "status" to "signal",
        "ageUpper" to ageUpper,
    )
}

internal fun noAgeSignalPayload(): Map<String, Any?> {
    return mapOf(
        "status" to "noSignal",
        "ageUpper" to null,
    )
}

internal fun replyWithAgeSignalError(
    result: MethodChannel.Result,
    error: Exception,
) {
    // Missing/outdated Play installations and non-Play installs cannot supply
    // a signal. Preserve Buzz's unsupported-environment no-signal policy.
    // Transport, binding, SDK integration, and unknown failures stay gated.
    if (error is AgeSignalsException && error.errorCode in setOf(
            AgeSignalsErrorCode.API_NOT_AVAILABLE,
            AgeSignalsErrorCode.PLAY_STORE_NOT_FOUND,
            AgeSignalsErrorCode.PLAY_SERVICES_NOT_FOUND,
            AgeSignalsErrorCode.PLAY_STORE_VERSION_OUTDATED,
            AgeSignalsErrorCode.PLAY_SERVICES_VERSION_OUTDATED,
            AgeSignalsErrorCode.APP_NOT_OWNED,
        )
    ) {
        result.success(noAgeSignalPayload())
        return
    }
    result.error(
        "age_signal_unavailable",
        "The age signal request failed.",
        error.javaClass.simpleName,
    )
}

internal object AndroidImageProcessor {
    fun decodeSrgbBitmap(bytes: ByteArray): Bitmap? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            decodeSrgbBitmapWithColorManagement(bytes)
        } else {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun decodeSrgbBitmapWithColorManagement(bytes: ByteArray): Bitmap? {
        val decoded = decodeColorManagedBitmap(bytes) ?: return null
        val srgb = ColorSpace.get(ColorSpace.Named.SRGB)
        if (decoded.config == Bitmap.Config.ARGB_8888 && decoded.colorSpace == srgb) return decoded

        val srgbBitmap = Bitmap.createBitmap(
            decoded.width,
            decoded.height,
            Bitmap.Config.ARGB_8888,
            decoded.hasAlpha(),
            srgb,
        )
        Canvas(srgbBitmap).drawBitmap(decoded, 0f, 0f, null)
        return srgbBitmap
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun decodeColorManagedBitmap(bytes: ByteArray): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching {
                val source = ImageDecoder.createSource(ByteBuffer.wrap(bytes))
                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    decoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
                }
            }.getOrNull()?.let { return it }
        }

        val options = BitmapFactory.Options().apply {
            inPreferredColorSpace = ColorSpace.get(ColorSpace.Named.SRGB)
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }

    fun encodeAndScrub(
        bitmap: Bitmap,
        format: Bitmap.CompressFormat,
    ): ByteArray? {
        val output = ByteArrayOutputStream()
        if (!bitmap.compress(format, 100, output)) return null

        return when (format) {
            Bitmap.CompressFormat.PNG -> AndroidMediaSanitizer.scrubPng(output.toByteArray())
            Bitmap.CompressFormat.JPEG -> AndroidMediaSanitizer.scrubJpeg(output.toByteArray())
            else -> error("Unsupported upload image format: $format")
        }
    }
}

class MainActivity : FlutterFragmentActivity() {
    private var mediaUploadChannel: MethodChannel? = null
    private var ageSignalChannel: MethodChannel? = null
    private var ageSignalRequestGeneration = 0
    private var pendingAgeSignalResult: MethodChannel.Result? = null
    private var huddleMediaPlugin: HuddleMediaPlugin? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        huddleMediaPlugin = HuddleMediaPlugin(
            this,
            flutterEngine.dartExecutor.binaryMessenger,
        )

        mediaUploadChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            MEDIA_UPLOAD_CHANNEL,
        ).also { channel ->
            channel.setMethodCallHandler { call, result ->
                when (call.method) {
                    SANITIZE_IMAGE_FOR_UPLOAD_METHOD -> {
                        handleSanitizeImageForUpload(call.arguments, result)
                    }
                    TRANSCODE_IMAGE_TO_JPEG_METHOD -> {
                        handleTranscodeImageToJpeg(call.arguments, result)
                    }
                    TRANSCODE_VIDEO_TO_MP4_METHOD -> {
                        handleTranscodeVideoToMp4(call.arguments, result)
                    }
                    GENERATE_VIDEO_POSTER_METHOD -> {
                        handleGenerateVideoPoster(call.arguments, result)
                    }
                    PACKAGE_VOICE_NOTE_FOR_UPLOAD_METHOD -> {
                        handlePackageVoiceNoteForUpload(call.arguments, result)
                    }
                    REQUIRES_LEGACY_MEDIA_STORAGE_PERMISSION_METHOD -> {
                        result.success(Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
                    }
                    else -> result.notImplemented()
                }
            }
        }

        ageSignalChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            AGE_SIGNAL_CHANNEL,
        ).also { channel ->
            channel.setMethodCallHandler { call, result ->
                when (call.method) {
                    REQUEST_AGE_SIGNAL_METHOD -> {
                        handleRequestAgeSignal(
                            AgeSignalsManagerFactory.create(applicationContext),
                            result,
                        )
                    }
                    CANCEL_AGE_SIGNAL_METHOD -> cancelAgeSignalRequest(result)
                    RESTART_AGE_SIGNAL_METHOD -> restartForAgeSignal(result)
                    else -> result.notImplemented()
                }
            }
        }
    }

    private fun handleRequestAgeSignal(
        ageSignalsManager: AgeSignalsManager,
        result: MethodChannel.Result,
    ) {
        if (pendingAgeSignalResult != null) {
            result.error("age_signal_in_flight", "An age signal request is already active.", null)
            return
        }
        ageSignalRequestGeneration += 1
        val generation = ageSignalRequestGeneration
        pendingAgeSignalResult = result
        val accessRequest = AgeSignalsAccessRequest.builder()
            .setActivity(this)
            .build()
        ageSignalsManager.requestAgeSignalsAccess(accessRequest)
            .addOnSuccessListener { accessResult ->
                if (accessResult.ageSignalsStatus() != AgeSignalsStatus.SHARED) {
                    completeAgeSignalRequest(generation, result) { replyWithNoAgeSignal(result) }
                    return@addOnSuccessListener
                }

                ageSignalsManager.checkAgeSignals(AgeSignalsRequest.builder().build())
                    .addOnSuccessListener { ageSignalsResult ->
                        completeAgeSignalRequest(generation, result) {
                            replyWithAgeSignal(result, ageSignalsResult.ageUpper())
                        }
                    }
                    .addOnFailureListener { error ->
                        completeAgeSignalRequest(generation, result) {
                            replyWithAgeSignalError(result, error)
                        }
                    }
            }
            .addOnFailureListener { error ->
                completeAgeSignalRequest(generation, result) {
                    replyWithAgeSignalError(result, error)
                }
            }
    }

    private fun completeAgeSignalRequest(
        generation: Int,
        result: MethodChannel.Result,
        reply: () -> Unit,
    ) {
        if (generation != ageSignalRequestGeneration || pendingAgeSignalResult !== result) return
        pendingAgeSignalResult = null
        reply()
    }

    private fun cancelAgeSignalRequest(result: MethodChannel.Result) {
        // Play age-signals 0.0.4 exposes non-cancellable Tasks. Retain the
        // original single flight rather than allowing an overlapping prompt.
        result.success(false)
    }

    private fun restartForAgeSignal(result: MethodChannel.Result) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent == null) {
            result.error("age_signal_restart_failed", "Buzz could not restart.", null)
            return
        }
        result.success(false)
        window.decorView.post {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(launchIntent)
            finishAffinity()
            Runtime.getRuntime().exit(0)
        }
    }

    private fun replyWithAgeSignal(
        result: MethodChannel.Result,
        ageUpper: Int?,
    ) {
        result.success(ageSignalPayload(ageUpper))
    }

    private fun replyWithNoAgeSignal(result: MethodChannel.Result) {
        result.success(noAgeSignalPayload())
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        huddleMediaPlugin?.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onDestroy() {
        huddleMediaPlugin?.dispose()
        huddleMediaPlugin = null
        super.onDestroy()
    }

    private fun handleSanitizeImageForUpload(
        arguments: Any?,
        result: MethodChannel.Result,
    ) {
        val payload = arguments as? Map<*, *> ?: run {
            invalidArguments(result, "Expected image bytes and mime type.")
            return
        }
        val bytes = payload["bytes"] as? ByteArray ?: run {
            invalidArguments(result, "Expected raw image bytes.")
            return
        }
        val mimeType = payload["mimeType"] as? String ?: run {
            invalidArguments(result, "Expected image mime type.")
            return
        }

        val format = sanitizeCompressFormatFor(mimeType)
        if (format == null) {
            result.error(
                "sanitize_failed",
                "Unable to sanitize picked image.",
                mimeType,
            )
            return
        }

        transformImageBytes(
            bytes = bytes,
            result = result,
            format = format,
            errorCode = "sanitize_failed",
            encodeFailureMessage = "Unable to sanitize picked image.",
            errorDetails = mimeType,
        )
    }

    private fun handleTranscodeImageToJpeg(
        arguments: Any?,
        result: MethodChannel.Result,
    ) {
        val bytes = arguments as? ByteArray ?: run {
            invalidArguments(result, "Expected raw image bytes.")
            return
        }

        transformImageBytes(
            bytes = bytes,
            result = result,
            format = Bitmap.CompressFormat.JPEG,
            errorCode = "transcode_failed",
            encodeFailureMessage = "Unable to convert picked image to JPEG.",
        )
    }

    private fun sanitizeCompressFormatFor(
        mimeType: String,
    ): Bitmap.CompressFormat? {
        return when (mimeType) {
            "image/jpeg" -> Bitmap.CompressFormat.JPEG
            "image/png", "image/webp" -> Bitmap.CompressFormat.PNG
            else -> null
        }
    }

    private fun transformImageBytes(
        bytes: ByteArray,
        result: MethodChannel.Result,
        format: Bitmap.CompressFormat,
        errorCode: String,
        encodeFailureMessage: String,
        errorDetails: Any? = null,
    ) {
        val bitmap = AndroidImageProcessor.decodeSrgbBitmap(bytes) ?: run {
            result.error(
                errorCode,
                "Unable to decode picked image.",
                null,
            )
            return
        }

        val transformedBytes = try {
            AndroidImageProcessor.encodeAndScrub(bitmap, format)
        } catch (_: IllegalArgumentException) {
            null
        } ?: run {
            result.error(
                errorCode,
                encodeFailureMessage,
                errorDetails,
            )
            return
        }

        result.success(transformedBytes)
    }

    private fun handleTranscodeVideoToMp4(
        arguments: Any?,
        result: MethodChannel.Result,
    ) {
        val sourcePath = arguments as? String ?: run {
            invalidArguments(result, "Expected source file path as String.")
            return
        }

        Thread {
            val outputFile = File(cacheDir, "${UUID.randomUUID()}.mp4")
            var muxer: MediaMuxer? = null
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(sourcePath)
                muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

                val trackIndices = mutableMapOf<Int, Int>()
                var copiedVideo = false
                var copiedAudio = false
                for (i in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: continue
                    val isVideo = mime.startsWith("video/")
                    val isAudio = mime.startsWith("audio/")
                    if ((!isVideo && !isAudio) || (isVideo && copiedVideo) || (isAudio && copiedAudio)) {
                        continue
                    }
                    val newIndex = muxer.addTrack(format)
                    trackIndices[i] = newIndex
                    extractor.selectTrack(i)
                    copiedVideo = copiedVideo || isVideo
                    copiedAudio = copiedAudio || isAudio
                }

                muxer.start()
                val buffer = ByteBuffer.allocate(1024 * 1024) // 1MB buffer
                val bufferInfo = android.media.MediaCodec.BufferInfo()

                while (true) {
                    val sampleSize = extractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break
                    val muxerTrack = trackIndices[extractor.sampleTrackIndex]
                    if (muxerTrack == null) {
                        extractor.advance()
                        continue
                    }
                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(muxerTrack, buffer, bufferInfo)
                    extractor.advance()
                }

                muxer.stop()
                result.success(outputFile.absolutePath)
            } catch (e: Exception) {
                outputFile.delete()
                result.error(
                    "transcode_failed",
                    e.message ?: "Video transcoding failed.",
                    null,
                )
            } finally {
                try { muxer?.release() } catch (_: Exception) {}
                extractor.release()
            }
        }.start()
    }

    private fun handleGenerateVideoPoster(
        arguments: Any?,
        result: MethodChannel.Result,
    ) {
        val sourcePath = arguments as? String ?: run {
            invalidArguments(result, "Expected source file path as String.")
            return
        }

        Thread {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(sourcePath)
                val source = retriever.getFrameAtTime(
                    0,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                ) ?: retriever.getFrameAtTime(
                    100_000,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                ) ?: throw IllegalArgumentException("Unable to decode a video frame.")
                val scale = minOf(1f, 720f / maxOf(source.width, source.height))
                val frame = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        source,
                        (source.width * scale).toInt(),
                        (source.height * scale).toInt(),
                        true,
                    ).also { source.recycle() }
                } else {
                    source
                }
                val bytes = AndroidImageProcessor.encodeAndScrub(
                    frame,
                    Bitmap.CompressFormat.JPEG,
                ) ?: throw IllegalArgumentException("Unable to encode a video preview.")
                frame.recycle()
                result.success(bytes)
            } catch (e: Exception) {
                result.error(
                    "poster_failed",
                    "Unable to create a video preview.",
                    e.message,
                )
            } finally {
                retriever.release()
            }
        }.start()
    }

    private fun handlePackageVoiceNoteForUpload(
        arguments: Any?,
        result: MethodChannel.Result,
    ) {
        val sourcePath = arguments as? String ?: run {
            invalidArguments(result, "Expected source file path as String.")
            return
        }

        Thread {
            try {
                result.success(
                    AndroidVoiceNotePackager.packageForUpload(
                        sourcePath = sourcePath,
                        cacheDirectory = cacheDir,
                    ),
                )
            } catch (error: Exception) {
                result.error(
                    "transcode_failed",
                    "Unable to assemble voice note for upload.",
                    error.message,
                )
            }
        }.start()
    }

    private fun invalidArguments(
        result: MethodChannel.Result,
        message: String,
    ) {
        result.error("invalid_arguments", message, null)
    }

    companion object {
        private const val MEDIA_UPLOAD_CHANNEL = "buzz/media_upload"
        private const val AGE_SIGNAL_CHANNEL = "buzz/age_signal"
        private const val REQUEST_AGE_SIGNAL_METHOD = "requestAgeSignal"
        private const val CANCEL_AGE_SIGNAL_METHOD = "cancelAgeSignalRequest"
        private const val RESTART_AGE_SIGNAL_METHOD = "restartForAgeSignal"
        private const val SANITIZE_IMAGE_FOR_UPLOAD_METHOD = "sanitizeImageForUpload"
        private const val TRANSCODE_IMAGE_TO_JPEG_METHOD = "transcodeImageToJpeg"
        private const val TRANSCODE_VIDEO_TO_MP4_METHOD = "transcodeVideoToMp4"
        private const val GENERATE_VIDEO_POSTER_METHOD = "generateVideoPoster"
        private const val PACKAGE_VOICE_NOTE_FOR_UPLOAD_METHOD = "packageVoiceNoteForUpload"
        private const val REQUIRES_LEGACY_MEDIA_STORAGE_PERMISSION_METHOD =
            "requiresLegacyMediaStoragePermission"
    }
}
